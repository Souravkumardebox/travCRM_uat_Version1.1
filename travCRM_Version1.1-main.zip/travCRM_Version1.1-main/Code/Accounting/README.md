# travCRM_microservises
Microservises for travCRM Debox Global
#------------------------------------------------------------------------
(Architecture of Refactored TraVCRM)
#------------------------------------------------------------------------

To understand directory structure please follow the file: "MSA_TRAVCRM.pdf"

