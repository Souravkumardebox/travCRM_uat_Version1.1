<?php
////////////////Define all table name here/////////////////////

/*-------FOR CUSTOM DB SELECTION  PGSQL OR MYSQL ------*/
define("_PGSQL_", "pgsql");
/*-----------------------------------------------------*/

define("_COUNTRY_MASTER_", "master.country_master");
define("_STATE_MASTER_", "master.stateMaster");
define("_CITY_MASTER_", "master.city_master");
define("_DESTINATION_MASTER_", "master.destination_master");
define("_LANGUAGE_MASTER_", "master.language_master");
define("_BUSINESS_TYPE_MASTER_", "master.business_type_master");

///////////////////////////////////////////////////////////////

?>